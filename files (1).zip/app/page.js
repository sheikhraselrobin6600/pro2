import GradientBorder from "../components/GradientBorder";
import { useProducts } from "../context/ProductContext";
import ProductCard from "../components/ProductCard";

export default function Home() {
  const { products } = useProducts();
  // Highlighted products: one from each section if highlight:true, else first product
  const highlights = [
    products.flash.find(p => p.highlight) || products.flash[0],
    products.mens.find(p => p.highlight) || products.mens[0],
    products.womens.find(p => p.highlight) || products.womens[0],
    products.baby.find(p => p.highlight) || products.baby[0],
  ].filter(Boolean);
  return (
    <main className="py-7">
      <GradientBorder>
        Glow & Grace
      </GradientBorder>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
        {highlights.map(product => (
          <ProductCard key={product.id} product={product}/>
        ))}
      </div>
    </main>
  );
}