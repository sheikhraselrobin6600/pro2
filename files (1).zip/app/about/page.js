export default function AboutPage() {
  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-4">About Glow & Grace</h2>
      <p className="mb-2">Glow & Grace - ই-কমার্স সাইট। এখানে আপনি সেরা বিউটি, কেয়ার এবং বেবি প্রোডাক্ট পাবেন।</p>
      <p>ডেভেলপার: <b>sheikhraselrobin6600</b></p>
    </div>
  );
}