import { useProducts } from "../../context/ProductContext";
import ProductCard from "../../components/ProductCard";
export default function BabyCarePage() {
  const { products } = useProducts();
  return (
    <div className="py-6">
      <h2 className="text-2xl font-bold mb-4">বেবি কেয়ার</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.baby.map(product => (
          <ProductCard key={product.id} product={product}/>
        ))}
      </div>
    </div>
  );
}