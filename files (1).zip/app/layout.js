import "./globals.css";
import { ThemeProvider } from "../context/ThemeContext";
import { ProductProvider } from "../context/ProductContext";
import Navbar from "../components/Navbar";

export const metadata = {
  title: "Glow & Grace",
  description: "Glow & Grace - Premium e-commerce",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-gradient-to-br from-pink-50 via-purple-50 to-yellow-100 dark:from-gray-900 dark:via-gray-950 dark:to-gray-900 min-h-screen">
        <ThemeProvider>
          <ProductProvider>
            <div className="max-w-5xl mx-auto">
              <Navbar />
              {children}
            </div>
          </ProductProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}