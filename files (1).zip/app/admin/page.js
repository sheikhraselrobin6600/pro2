"use client";
import { useState } from "react";
import AdminLogin from "../../components/AdminLogin";
import { useProducts } from "../../context/ProductContext";
import ProductForm from "../../components/ProductForm";

const sections = [
  { key: "flash", label: "Flash Sale" },
  { key: "mens", label: "Mens Care" },
  { key: "womens", label: "Womens Care" },
  { key: "baby", label: "Baby Care" },
];

export default function AdminPage() {
  const { products, addProduct, removeProduct, replaceProduct } = useProducts();
  const [isLogged, setIsLogged] = useState(typeof window!=="undefined" && localStorage.getItem("admin")==="yes");
  const [edit, setEdit] = useState({});
  if (!isLogged) return <AdminLogin onLogin={()=>setIsLogged(true)} />;
  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-6">Admin Panel</h2>
      {sections.map(section => (
        <div key={section.key} className="mb-8">
          <h3 className="text-xl font-semibold mb-3">{section.label}</h3>
          <ProductForm
            onSubmit={prod => addProduct(section.key, prod)}
            section={section.key}
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            {products[section.key].map(prod => (
              <div key={prod.id} className="border rounded-xl p-2 relative">
                {edit[prod.id] ? (
                  <ProductForm
                    init={prod}
                    onSubmit={newProd => {
                      replaceProduct(section.key, prod.id, newProd);
                      setEdit(e => ({ ...e, [prod.id]: false }));
                    }}
                  />
                ) : (
                  <>
                    <img src={prod.image} className="h-16 mx-auto" />
                    <div className="font-bold">{prod.name}</div>
                    <div>
                      <span className="text-pink-500 font-bold">৳{prod.price}</span>
                      {prod.oldPrice && (
                        <span className="line-through text-gray-400 text-sm ml-2">৳{prod.oldPrice}</span>
                      )}
                    </div>
                    <div className="flex gap-2 mt-2">
                      <button className="bg-yellow-400 px-3 py-1 rounded text-xs"
                        onClick={() => setEdit(e => ({ ...e, [prod.id]: true }))}
                      >Edit</button>
                      <button className="bg-red-400 px-3 py-1 rounded text-xs"
                        onClick={() => removeProduct(section.key, prod.id)}
                      >Remove</button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}