"use client";
import { createContext, useContext, useEffect, useState } from "react";

const initialProducts = {
  flash: [
    {
      id: 1,
      name: "Glow Face Serum",
      image: "/img/serum.png",
      price: 650,
      oldPrice: 900,
      category: "womens",
      highlight: true,
    },
  ],
  mens: [
    {
      id: 2,
      name: "Men's Aftershave",
      image: "/img/aftershave.png",
      price: 400,
      oldPrice: 500,
      category: "mens",
      highlight: true,
    },
  ],
  womens: [
    {
      id: 3,
      name: "Graceful Lipstick",
      image: "/img/lipstick.png",
      price: 320,
      oldPrice: 399,
      category: "womens",
    },
  ],
  baby: [
    {
      id: 4,
      name: "Baby Lotion",
      image: "/img/babylotion.png",
      price: 220,
      oldPrice: 300,
      category: "baby",
    },
  ],
};

const ProductContext = createContext();

export function ProductProvider({ children }) {
  const [products, setProducts] = useState(initialProducts);

  useEffect(() => {
    const saved = localStorage.getItem("products");
    if (saved) setProducts(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("products", JSON.stringify(products));
  }, [products]);

  // Admin product handlers
  const addProduct = (section, product) => {
    setProducts((prev) => ({
      ...prev,
      [section]: [...prev[section], { ...product, id: Date.now() }],
    }));
  };
  const removeProduct = (section, id) => {
    setProducts((prev) => ({
      ...prev,
      [section]: prev[section].filter((p) => p.id !== id),
    }));
  };
  const replaceProduct = (section, id, newProduct) => {
    setProducts((prev) => ({
      ...prev,
      [section]: prev[section].map((p) =>
        p.id === id ? { ...p, ...newProduct } : p
      ),
    }));
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        addProduct,
        removeProduct,
        replaceProduct,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
}
export const useProducts = () => useContext(ProductContext);