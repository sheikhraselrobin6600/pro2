import { useState } from "react";
export default function AdminLogin({ onLogin }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  function handleSubmit(e) {
    e.preventDefault();
    if (password === "017647132066600Robin") {
      localStorage.setItem("admin", "yes");
      onLogin();
    } else {
      setError("Password ভুল!");
    }
  }
  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <input type="password" value={password} onChange={e=>setPassword(e.target.value)}
        className="px-4 py-2 rounded-xl border" placeholder="এডমিন পাসওয়ার্ড" />
      <button
        className="bg-gradient-to-r from-pink-400 via-purple-400 to-yellow-300 text-white py-2 rounded-xl font-bold"
        type="submit"
      >লগইন</button>
      {error && <span className="text-red-500">{error}</span>}
    </form>
  );
}