export default function ProductCard({ product }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-4 flex flex-col items-center transition hover:scale-105">
      <img src={product.image} alt={product.name} className="h-32 object-contain mb-2" />
      <h3 className="text-lg font-semibold">{product.name}</h3>
      <div className="flex gap-2 items-center">
        <span className="text-pink-500 font-bold text-xl">৳{product.price}</span>
        {product.oldPrice && (
          <span className="line-through text-gray-400 text-sm">৳{product.oldPrice}</span>
        )}
      </div>
    </div>
  );
}