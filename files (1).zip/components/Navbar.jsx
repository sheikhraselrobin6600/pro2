"use client";
import Link from "next/link";
import ThemeToggle from "./ThemeToggle";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "Flash Sale", path: "/flash-sale" },
  { name: "Mens Care", path: "/mens-care" },
  { name: "Womens Care", path: "/womens-care" },
  { name: "Baby Care", path: "/baby-care" },
  { name: "Admin", path: "/admin" },
  { name: "About", path: "/about" },
];

export default function Navbar() {
  const pathname = usePathname();
  const [hovered, setHovered] = useState(-1);
  return (
    <nav className="flex items-center justify-between py-3 px-6 bg-white/70 dark:bg-gray-950/70 shadow-lg rounded-b-xl">
      <div className="flex items-center gap-8">
        {navLinks.map((link, i) => (
          <Link key={link.name} href={link.path}>
            <span
              className={`relative px-4 py-2 mx-1 rounded-full transition-all duration-300
                ${pathname === link.path
                  ? "bg-gradient-to-r from-pink-400 via-purple-400 to-yellow-300 text-white shadow-xl"
                  : "hover:bg-gradient-to-r hover:from-pink-100 hover:via-purple-100 hover:to-yellow-100"}
                ${hovered === i ? "scale-105" : ""}
              `}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(-1)}
            >
              {link.name}
            </span>
          </Link>
        ))}
      </div>
      <ThemeToggle />
    </nav>
  );
}