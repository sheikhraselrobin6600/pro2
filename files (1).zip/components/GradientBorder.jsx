export default function GradientBorder({ children }) {
  return (
    <div className="relative p-1 rounded-full overflow-hidden mb-4">
      <div className="absolute inset-0 animate-spin-slow bg-gradient-to-r from-pink-400 via-purple-400 to-yellow-300 blur-lg opacity-60"></div>
      <div className="relative z-10 bg-white dark:bg-gray-900 rounded-full px-8 py-3 text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-yellow-300 shadow-lg">
        {children}
      </div>
    </div>
  );
}