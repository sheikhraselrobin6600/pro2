import { useState } from "react";
export default function ProductForm({ onSubmit, section, init }) {
  const [data, setData] = useState(
    init || { name: "", image: "", price: "", oldPrice: "" }
  );
  return (
    <form
      className="flex flex-col gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({ ...data, price: Number(data.price), oldPrice: Number(data.oldPrice) });
        setData({ name: "", image: "", price: "", oldPrice: "" });
      }}
    >
      <input className="border px-2 py-1 rounded" placeholder="প্রোডাক্ট নাম" value={data.name} onChange={e=>setData({...data, name: e.target.value})}/>
      <input className="border px-2 py-1 rounded" placeholder="ছবি URL" value={data.image} onChange={e=>setData({...data, image: e.target.value})}/>
      <input className="border px-2 py-1 rounded" placeholder="মূল্য" type="number" value={data.price} onChange={e=>setData({...data, price: e.target.value})}/>
      <input className="border px-2 py-1 rounded" placeholder="পূর্বের মূল্য" type="number" value={data.oldPrice} onChange={e=>setData({...data, oldPrice: e.target.value})}/>
      <button className="bg-pink-400 text-white rounded px-4 py-1 mt-1">যোগ করুন</button>
    </form>
  );
}