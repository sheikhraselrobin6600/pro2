import { useTheme } from "../context/ThemeContext";
export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  return (
    <button
      aria-label="Toggle Theme"
      onClick={toggleTheme}
      className="ml-4 p-2 rounded-full bg-gradient-to-tr from-pink-400 via-purple-400 to-yellow-300 shadow-lg transition hover:scale-110"
    >
      {theme === "light" ? (
        <svg width={24} height={24} fill="none"><circle cx={12} cy={12} r={6} fill="#FBBF24"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" stroke="#FBBF24" strokeWidth={2}/></svg>
      ) : (
        <svg width={24} height={24} fill="none"><path d="M21 12.79A9 9 0 1111.21 3a7 7 0 109.79 9.79z" fill="#6366F1"/></svg>
      )}
    </button>
  );
}